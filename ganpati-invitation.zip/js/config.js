/**
 * Invitation Content Configuration
 * Easily customize the home Ganpati celebration details in one place.
 */

export const invitationConfig = {
  // Sacred Sanskrit Invocations
  shlokas: {
    pranam: "ॐ गं गणपतये नमः",
    invocation: "श्री गणेशाय नमः",
    morya: "गणपती बाप्पा मोरया • मंगलमूर्ती मोरया",
    greeting: "WITH HEARTS FULL OF JOY AND DEVOTION"
  },

  // Family & Host Details
  hostName: "THE SHARMA FAMILY",
  familyMembers: "Anand, Sunita & Family",

  // Dates & Timings
  date: "Friday, 19th September 2026",
  darshanTime: "10:00 AM – 10:00 PM",
  aartiTime: "Morning Aarti: 11:30 AM | Evening Aarti: 7:30 PM",
  prasadTime: "Throughout the Day",

  // Location & Venue
  venueName: "Sharma Residence (Ganesh Kutir)",
  venueAddress: "Flat 402, Sai Sparsh Residency, 14th Cross, Green Glen Layout, Bellandur, Bengaluru",
  
  // Interactive Links
  mapsUrl: "https://maps.google.com/?q=Bellandur+Bengaluru",
  whatsappUrl: "https://api.whatsapp.com/send?text=We%20would%20love%20to%20join%20for%20Bappa%27s%20Darshan!",

  // Curated High-Definition Photographic Assets
  images: {
    hero: "https://images.unsplash.com/photo-1567591370504-8b631d87e076?auto=format&fit=crop&w=1920&q=85",
    darshanFull: "https://images.unsplash.com/photo-1567591370317-5e669e4693b7?auto=format&fit=crop&w=1600&q=85",
    darshanClose: "https://images.unsplash.com/photo-1599839575945-a9e5af0c3fa5?auto=format&fit=crop&w=1200&q=85",
    darshanDetail: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=85",
    aarti: "https://images.unsplash.com/photo-1605371924599-2d0365da1ae0?auto=format&fit=crop&w=1200&q=85",
    flowers: "https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=1200&q=85",
    prasad: "https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=1200&q=85"
  }
};

/**
 * Interactions & Utilities
 * Micro-interactions, directions, RSVP, return to top.
 */

import { scrollTo } from './smooth-scroll.js';
import { invitationConfig } from './config.js';

export function initInteractions() {
  // Return to Bappa (top)
  const returnBtn = document.getElementById('return-to-top-btn');
  if (returnBtn) {
    returnBtn.addEventListener('click', () => {
      scrollTo(0, { duration: 2.2 });
    });
  }

  // Begin Darshan (scroll indicator)
  const scrollIndicator = document.getElementById('hero-scroll-indicator');
  if (scrollIndicator) {
    scrollIndicator.addEventListener('click', () => {
      scrollTo('#transition', { duration: 1.4 });
    });
  }

  // Google Maps Directions
  const directionsBtn = document.getElementById('get-directions-btn');
  if (directionsBtn) {
    directionsBtn.addEventListener('click', (e) => {
      if (invitationConfig.mapsUrl) {
        window.open(invitationConfig.mapsUrl, '_blank', 'noopener,noreferrer');
      }
    });
  }

  // WhatsApp Share / RSVP
  const whatsappBtns = document.querySelectorAll('.whatsapp-share-btn');
  whatsappBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      if (invitationConfig.whatsappUrl) {
        window.open(invitationConfig.whatsappUrl, '_blank', 'noopener,noreferrer');
      }
    });
  });

  // Populate Dynamic Content from Config
  populateConfigContent();
}

function populateConfigContent() {
  // Host Name
  const hostElements = document.querySelectorAll('[data-config="hostName"]');
  hostElements.forEach(el => el.textContent = invitationConfig.hostName);

  // Date
  const dateElements = document.querySelectorAll('[data-config="date"]');
  dateElements.forEach(el => el.textContent = invitationConfig.date);

  // Darshan Time
  const darshanElements = document.querySelectorAll('[data-config="darshanTime"]');
  darshanElements.forEach(el => el.textContent = invitationConfig.darshanTime);

  // Aarti Time
  const aartiElements = document.querySelectorAll('[data-config="aartiTime"]');
  aartiElements.forEach(el => el.textContent = invitationConfig.aartiTime);

  // Venue Name & Address
  const venueNameElements = document.querySelectorAll('[data-config="venueName"]');
  venueNameElements.forEach(el => el.textContent = invitationConfig.venueName);

  const venueAddressElements = document.querySelectorAll('[data-config="venueAddress"]');
  venueAddressElements.forEach(el => el.textContent = invitationConfig.venueAddress);
}
